package com.csc.helloandroid;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.telephony.SmsManager;

public class MainActivity extends AppCompatActivity {
    Button sendSMS;
    EditText e1;
    EditText e2;
    /*TextView t1;*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendSMS = (Button) findViewById(R.id.button);
        e1 = (EditText) findViewById(R.id.editText3);
        e2 = (EditText) findViewById(R.id.editText4);
        /*t1 = (TextView) findViewById(R.id.textView);*/
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);
        sendSMS.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                /*int num1 = Integer.parseInt(e1.getText().toString());*
                /*int num2 = Integer.parseInt(e2.getText().toString());*/
                /*int sum = num1+num2;*/
                /*t1.setText(Integer.toString(sum));*/
                String myMsg = e2.getText().toString();
                String theNumber = e1.getText().toString();
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(theNumber,null,myMsg,pi,null);
                /*sendMsg(theNumber,myMsg);*/
                /*t1.setText(myMsg);*/
            }
        });
    }
    /*protected void sendMsg(String theNumber, String myMsg) {
        Intent intent=new Intent(getApplicationContext(),MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(theNumber,null,myMsg,pi,null);

    }*/
}
